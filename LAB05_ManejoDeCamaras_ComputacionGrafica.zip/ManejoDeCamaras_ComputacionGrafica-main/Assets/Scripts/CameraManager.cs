using UnityEngine;

public class CameraManager : MonoBehaviour
{
    [Header("C�maras")]
    public Camera salonCamera;
    public Camera primeraPersonaCamera;

    [Header("Jugador")]
    public Transform player;

    void Start()
    {
        // Desactivar la Main Camera (este script)
        GetComponent<Camera>().enabled = false;
     
    }

    public void ActivarCamaraSalon()
    {
        Debug.Log("Entrando al sal�n - tercera persona");
        salonCamera.enabled = true;
        primeraPersonaCamera.enabled = false;
        SetPlayerVisible(true);
    }

    public void ActivarPrimeraPersona()
    {
        Debug.Log("En el pasillo - primera persona");
        salonCamera.enabled = false;
        primeraPersonaCamera.enabled = true;
        SetPlayerVisible(false);
    }

    void SetPlayerVisible(bool visible)
    {
        if (player != null)
        {
            Renderer[] renderers = player.GetComponentsInChildren<Renderer>();
            foreach (Renderer renderer in renderers)
            {
                renderer.enabled = visible;
            }
        }
    }
} 