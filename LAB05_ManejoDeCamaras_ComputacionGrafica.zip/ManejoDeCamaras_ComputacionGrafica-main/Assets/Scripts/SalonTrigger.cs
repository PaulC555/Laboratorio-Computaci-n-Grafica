using UnityEngine;

public class SalonTrigger : MonoBehaviour
{
    public CameraManager cameraManager;
    [Header("�El personaje empieza en el sal�n?")]
    public bool empiezaEnSalon = true; // Marca esto como TRUE

    private bool estaEnSalon = false;

    void Start()
    {
        // Configurar estado inicial
        estaEnSalon = empiezaEnSalon;

        if (estaEnSalon)
        {
            Debug.Log("Inicio: En el sal�n - Tercera persona");
            cameraManager.ActivarCamaraSalon();
        }
        else
        {
            Debug.Log("Inicio: En el pasillo - Primera persona");
            cameraManager.ActivarPrimeraPersona();
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Jugador cruza el trigger");
            CambiarEstado();
        }
    }

    void CambiarEstado()
    {
        estaEnSalon = !estaEnSalon;

        if (estaEnSalon)
        {
            Debug.Log("ENTRA al sal�n - Tercera persona");
            cameraManager.ActivarCamaraSalon();
        }
        else
        {
            Debug.Log("SALE al pasillo - Primera persona");
            cameraManager.ActivarPrimeraPersona();
        }
    }
}